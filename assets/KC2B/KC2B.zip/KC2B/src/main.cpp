#include <iostream>
#include <time.h>  
#include <stdio.h>  

#include <string.h>  
#include<stdint.h>  
#include <unistd.h>  
#include <fcntl.h> 
#include <errno.h>  
#include <termios.h> 
#include <vector>
using namespace std;

#include <opencv2/core/core.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>

using namespace cv;

void getRed(const vector< Mat > & hsvSplit, Mat & dst)
{
  static int red_LowH = 10; /*threshold of  hue*/
  static int red_HighH = 235;
  static int red_LowS = 70; /*threshold of saturation*/
  static int red_LowV = 60; /*threshold of value*/

  static Mat red_h, red_h1, red_h2, red_s, red_v;
  threshold(hsvSplit[0], red_h1, red_LowH, 255, THRESH_BINARY_INV);
  threshold(hsvSplit[0], red_h2, red_HighH, 255, THRESH_BINARY);
  threshold(hsvSplit[1], red_s, red_LowS, 255, THRESH_BINARY);
  threshold(hsvSplit[2], red_v, red_LowV, 255, THRESH_BINARY);

  bitwise_or(red_h1, red_h2, red_h);
  bitwise_and(red_h, red_s, dst);
  bitwise_and(dst, red_v, dst);

  namedWindow("Red", CV_WINDOW_AUTOSIZE);
  imshow("Red", dst);
  cvCreateTrackbar("LowH", "Red", &red_LowH,
          255); /*control trackbar of  hue*/
  cvCreateTrackbar("HighH", "Red", &red_HighH, 255);
  cvCreateTrackbar("LowS", "Red", &red_LowS,
          255); /*control trackbar of saturation*/
  cvCreateTrackbar("LowV", "Red", &red_LowV, 255);
}

void getBlue(const vector< Mat > & hsvSplit, Mat & dst)
{
  static int blue_LowH = 140; /*threshold of  hue*/
  static int blue_HighH = 170;
  static int blue_LowS = 100; /*threshold of saturation*/
  static int blue_LowV = 70; /*threshold of value*/

  static Mat blue_h, blue_h1, blue_h2, blue_s, blue_v;
  threshold(hsvSplit[0], blue_h1, blue_LowH, 255, THRESH_BINARY);
  threshold(hsvSplit[0], blue_h2, blue_HighH, 255, THRESH_BINARY_INV);
  threshold(hsvSplit[1], blue_s, blue_LowS, 255, THRESH_BINARY);
  threshold(hsvSplit[2], blue_v, blue_LowV, 255, THRESH_BINARY);

  bitwise_and(blue_h1, blue_h2, blue_h);
  bitwise_and(blue_h, blue_s, dst);
  bitwise_and(dst, blue_v, dst);

  namedWindow("blue", CV_WINDOW_AUTOSIZE);
  imshow("blue", dst);
  cvCreateTrackbar("LowH", "blue", &blue_LowH,
          255); /*control trackbar of  hue*/
  cvCreateTrackbar("HighH", "blue", &blue_HighH, 255);
  cvCreateTrackbar("LowS", "blue", &blue_LowS,
          255); /*control trackbar of saturation*/
  cvCreateTrackbar("LowV", "blue", &blue_LowV, 255);
}

void findCircle(Mat & src, Point2f & center, float & radius)
{
    radius = 0;
    vector<vector<Point> > contours;
    findContours(src, contours, CV_RETR_EXTERNAL, CV_CHAIN_APPROX_SIMPLE);
    for(uint i=0; i < contours.size(); ++i)
    {
        int area = contourArea(contours[i]);
        if(area < 20)
            continue;
        minEnclosingCircle(contours[i], center, radius);
        float circleArea= 3.141592 * radius * radius;
        if(area / circleArea < 0.5)
        {
            radius = 0;
            continue;
        }
        else
            return;
    }
}

float getBlackRatio(Mat & src, Point2f & center, float & radius)
{
    int ctr = 0;
    vector<Point > circle_pt;
    ellipse2Poly(center, Size(radius + 10, radius + 10), 0, 0, 360, 4, circle_pt);
    for(uint i=0; i < circle_pt.size(); ++i)
    {
        int x = circle_pt[i].x;
        int y = circle_pt[i].y;
        if(x < 0 || x > src.cols || y < 0 || y > src.rows)
            continue;
        if(*(src.ptr<uchar>(y) + x) == 0)
            ++ctr;
    }
    return float(ctr) / circle_pt.size();
}

int set_opt(int fd,int nSpeed, int nBits, char nEvent, int nStop)  
{  
	struct termios newtio,oldtio;  
	if  ( tcgetattr( fd,&oldtio)  !=  0)  
	{  
		perror("SetupSerial 1");  
		return -1;  
	}  
	bzero( &newtio, sizeof( newtio ) );  
	newtio.c_cflag  |=  CLOCAL | CREAD;  
	newtio.c_cflag &= ~CSIZE;  

	switch( nBits )  
	{  
	case 7:  
		newtio.c_cflag |= CS7;  
		break;  
	case 8:  
		newtio.c_cflag |= CS8;  
		break;  
	}  

	switch( nEvent )  
	{  
	case 'O':                     //ÆæÐ£Ñé  
		newtio.c_cflag |= PARENB;  
		newtio.c_cflag |= PARODD;  
		newtio.c_iflag |= (INPCK | ISTRIP);  
		break;  
	case 'E':                     //Å¼Ð£Ñé  
		newtio.c_iflag |= (INPCK | ISTRIP);  
		newtio.c_cflag |= PARENB;  
		newtio.c_cflag &= ~PARODD;  
		break;  
	case 'N':                    //ÎÞÐ£Ñé  
		newtio.c_cflag &= ~PARENB;  
		break;  
	}  

	switch( nSpeed )  
	{  
	case 2400:  
		cfsetispeed(&newtio, B2400);  
		cfsetospeed(&newtio, B2400);  
		break;  
	case 4800:  
		cfsetispeed(&newtio, B4800);  
		cfsetospeed(&newtio, B4800);  
		break;  
	case 9600:  
		cfsetispeed(&newtio, B9600);  
		cfsetospeed(&newtio, B9600);  
		break;  
	case 115200:  
		cfsetispeed(&newtio, B115200);  
		cfsetospeed(&newtio, B115200);  
		break;  
	default:  
		cfsetispeed(&newtio, B9600);  
		cfsetospeed(&newtio, B9600);  
		break;  
	}  
	if( nStop == 1 )  
	{  
		newtio.c_cflag &=  ~CSTOPB;  
	}  
	else if ( nStop == 2 )  
	{  
		newtio.c_cflag |=  CSTOPB;  
	}  
	newtio.c_cc[VTIME]  = 0;  
	newtio.c_cc[VMIN] = 0;  
	tcflush(fd,TCIFLUSH);  
	if((tcsetattr(fd,TCSANOW,&newtio))!=0)  
	{  
		perror("com set error");  
		return -1;  
	}  
	printf("set done!\n");  
	return 0;  
}  

int main(int argc, char *argv[])
{
    cout << "Open: " << argv[1] << endl;
	int fd= open(argv[1], O_RDWR | O_NOCTTY | O_NDELAY);
	if(fd <0)  
	{  
		perror("open_port error");  
		return -1;  
	}  
	int i;  
	if((i=set_opt(fd,9600,8,'N',1))<0)
	{  
		perror("set_opt error");  
		return -1;  
	}  
	char send[5] = "W";
	//char buf[40] = {0};
    cv::VideoCapture cap(0);
    //cv::VideoCapture cap("/home/jachinshen/Projects/python/OpenCV/KC2B/123.mp4"); 
    cv::Mat src, hsv, red, blue, gray;
    vector<Mat > hsvSplit;
    Point2f red_center, blue_center;
    float red_radius, blue_radius;
    float red_black_ratio, blue_black_ratio;

    cv::namedWindow("frame", 1); 
    cap.read(src);

    cv::VideoWriter g_writer;
    bool is_record = false;
    char tmp;
    cout << "Do you want to record?(y/n)" << endl;
    cin >> tmp;
    if (tmp == 'y') {
        is_record = true;
        g_writer.open("/home/jachinshen/视频/KC2B.avi", CV_FOURCC('P', 'I', 'M', '1'), 30,
                  cv::Size(640, 480));
    }

    imshow("frame", src);
    cv::waitKey(0);
    while(cap.read(src))	
    {
        GaussianBlur(src, src, Size(3, 3), 0);
        cvtColor(src, hsv, CV_BGR2HSV_FULL);
        cvtColor(src, gray, CV_BGR2GRAY);
        static int gray_thres = 128;
        threshold(gray, gray, gray_thres, 255, THRESH_BINARY);
        imshow("gray", gray);
        cvCreateTrackbar("thres", "gray", &gray_thres, 255);
        split(hsv, hsvSplit);
        getRed(hsvSplit, red);
        findCircle(red, red_center, red_radius);
        circle(src, red_center, red_radius + 10, Scalar(0,0,255), 0);
        if(red_radius > 0)
            red_black_ratio = getBlackRatio(gray, red_center, red_radius);
        else
            red_black_ratio = 0;

        getBlue(hsvSplit, blue);
        findCircle(blue, blue_center, blue_radius);
        circle(src, blue_center, blue_radius + 10, Scalar(255,0,0), 0);
        if(blue_radius > 0)
            blue_black_ratio = getBlackRatio(gray, blue_center, blue_radius);
        else
            blue_black_ratio = 0;

        cout << "Red: " << red_black_ratio << " Blue: " << blue_black_ratio << endl;
        if(red_black_ratio > blue_black_ratio)
        {
            cout << "Turn Right!" << endl;
            send[0] = 'E';
        }
        else
        {
            cout << "Turn Left!" << endl;
            send[0] = 'Q';
        }
        //if(red_black_ratio < 0.1 && blue_black_ratio < 0.1)
        //{
            //cout << "Go Ahead!" << endl;
            //send[0] = 'W';
        //}
        //else if(red_black_ratio >= 0.1)
        //{
            //cout << "Turn Right!" << endl;
            //send[0] = 'E';
        //}
        //else
        //{
            //cout << "Turn Left!" << endl;
            //send[0] = 'Q';
        //}

        write(fd,send,1);
        cout << "Send:" << send << endl;
        //read(fd,buf,30);
        //cout << "Receive:" << buf << endl;
        imshow("frame", src);
        if(is_record)
            g_writer.write(src);
        waitKey(1);
    }
    cap.release();
}
